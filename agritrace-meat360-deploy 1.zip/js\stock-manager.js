/**
 * Module Spécialisé : Gestion des Stocks, Réconciliation d'Effectifs Réels & Prévention des Vols
 * Système anti-coulage pour abattoirs, ateliers de découpe et grossistes en viande
 */

const StockManager = {
  activeLocationFilter: 'all',

  init() {
    this.renderStockKPIs();
    this.renderInventoryTable();
    this.renderMovementsTable();
  },

  // Calcul dynamique des statistiques de stocks et des coûts de vol
  computeStockMetrics() {
    let totalTheoreticalWeight = 0;
    let totalPhysicalWeight = 0;
    let totalTheftLossCost = 0;
    let missingPiecesCount = 0;
    let criticalAlertsCount = 0;

    TRACE_DATA.inventoryItems.forEach(item => {
      totalTheoreticalWeight += item.theoreticalWeightKg;
      totalPhysicalWeight += item.physicalWeightKg;

      const qtyDelta = item.theoreticalQty - item.physicalQty;
      if (qtyDelta > 0) {
        missingPiecesCount += qtyDelta;
        // Calcul du coût financier du vol (poids unitaire moyen * prix/kg)
        const avgWeightPerPiece = item.theoreticalWeightKg / item.theoreticalQty;
        const lossKg = qtyDelta * avgWeightPerPiece;
        const lossValue = lossKg * item.pricePerKg;
        totalTheftLossCost += lossValue;
      }

      if (item.status === 'SUSPICION_VOL') {
        criticalAlertsCount++;
      }
    });

    const weightLossTotal = totalTheoreticalWeight - totalPhysicalWeight;
    const globalShrinkagePct = totalTheoreticalWeight > 0 ? (weightLossTotal / totalTheoreticalWeight) * 100 : 0;

    return {
      totalTheoreticalWeight: Math.round(totalTheoreticalWeight * 10) / 10,
      totalPhysicalWeight: Math.round(totalPhysicalWeight * 10) / 10,
      totalTheftLossCost: Math.round(totalTheftLossCost * 100) / 100,
      missingPiecesCount,
      criticalAlertsCount,
      weightLossTotal: Math.round(weightLossTotal * 10) / 10,
      globalShrinkagePct: Math.round(globalShrinkagePct * 100) / 100
    };
  },

  renderStockKPIs() {
    const metrics = this.computeStockMetrics();

    const elTheftCost = document.getElementById('kpiTheftLossCost');
    const elMissingPieces = document.getElementById('kpiMissingPieces');
    const elRealWeight = document.getElementById('kpiRealStockWeight');
    const elShrinkageRate = document.getElementById('kpiGlobalShrinkage');

    if (elTheftCost) elTheftCost.textContent = `${metrics.totalTheftLossCost.toLocaleString('fr-FR', { minimumFractionDigits: 2 })} €`;
    if (elMissingPieces) elMissingPieces.textContent = metrics.missingPiecesCount;
    if (elRealWeight) elRealWeight.textContent = `${(metrics.totalPhysicalWeight / 1000).toFixed(2)} t`;
    if (elShrinkageRate) elShrinkageRate.textContent = `${metrics.globalShrinkagePct} %`;
  },

  renderInventoryTable() {
    const tbody = document.getElementById('stockTableBody');
    if (!tbody) return;

    const filtered = TRACE_DATA.inventoryItems.filter(item => {
      if (this.activeLocationFilter === 'all') return true;
      return item.locationId === this.activeLocationFilter;
    });

    tbody.innerHTML = filtered.map(item => {
      const qtyDiff = item.physicalQty - item.theoreticalQty;
      const weightDiff = Math.round((item.physicalWeightKg - item.theoreticalWeightKg) * 10) / 10;
      const avgUnitWeight = item.theoreticalWeightKg / item.theoreticalQty;
      const pieceCostLoss = qtyDiff < 0 ? Math.abs(qtyDiff) * avgUnitWeight * item.pricePerKg : 0;

      const isTheft = item.status === 'SUSPICION_VOL';
      const loc = TRACE_DATA.stockLocations.find(l => l.id === item.locationId);

      return `
        <tr class="hover:bg-slate-50 transition border-b border-slate-100 ${isTheft ? 'bg-red-50/80' : ''}">
          <td class="py-3 px-4">
            <span class="font-mono font-bold text-xs text-slate-800">${item.sku}</span>
            <div class="text-[11px] text-slate-600 font-semibold">${item.designation}</div>
            <div class="text-[10px] text-slate-500">${item.category} &bull; <span class="font-medium text-emerald-800">${loc ? loc.name : ''}</span></div>
          </td>
          
          <td class="py-3 px-4 text-xs font-mono">
            <div class="text-slate-500">Théorique : <strong class="text-slate-800">${item.theoreticalQty}</strong> ${item.unit}</div>
            <div class="text-slate-500">Poids théo : ${item.theoreticalWeightKg} kg</div>
          </td>

          <td class="py-3 px-4 text-xs font-mono">
            <div class="font-bold text-slate-900">Physique : <span class="${qtyDiff < 0 ? 'text-red-600 font-extrabold' : 'text-emerald-700'}">${item.physicalQty}</span> ${item.unit}</div>
            <div class="text-slate-700">Poids réel : ${item.physicalWeightKg} kg</div>
          </td>

          <td class="py-3 px-4 text-xs">
            ${qtyDiff < 0 ? `
              <div class="font-mono font-black text-red-600 flex items-center gap-1">
                <i class="fa-solid fa-arrow-trend-down"></i> ${qtyDiff} ${item.unit} (${weightDiff} kg)
              </div>
              <div class="text-[11px] font-bold text-red-700 mt-0.5">
                Perte : -${pieceCostLoss.toFixed(2)} €
              </div>
              <div class="text-[10px] text-slate-500">Coulage mesuré : ${item.measuredLossPct}% (Norme : ${item.normalShrinkagePct}%)</div>
            ` : `
              <div class="font-mono font-semibold text-emerald-700 flex items-center gap-1">
                <i class="fa-solid fa-check"></i> ${qtyDiff} (0 éc.)
              </div>
              <div class="text-[10px] text-slate-500">Ressuage normal : ${item.measuredLossPct}%</div>
            `}
          </td>

          <td class="py-3 px-4">
            ${isTheft ? `
              <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-black bg-red-600 text-white animate-pulse">
                <i class="fa-solid fa-hand-holding-dollar"></i> VOL SUSPECTÉ
              </span>
              <div class="text-[10px] text-red-800 font-medium mt-1 leading-tight">${item.missingDetail || 'Écart physique non justifié'}</div>
            ` : `
              <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">
                <i class="fa-solid fa-shield-check"></i> Stock Justifié
              </span>
            `}
          </td>

          <td class="py-3 px-4 text-right">
            <button onclick="StockManager.inspectStockDiscrepancy('${item.sku}')" class="px-2.5 py-1 bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 rounded text-xs font-semibold shadow-sm">
              <i class="fa-solid fa-magnifying-glass-chart"></i> Audit
            </button>
          </td>
        </tr>
      `;
    }).join('');

    this.renderStockKPIs();
  },

  renderMovementsTable() {
    const tbody = document.getElementById('movementsTableBody');
    if (!tbody) return;

    tbody.innerHTML = TRACE_DATA.stockMovements.map(m => {
      const isSuspect = m.status.includes('ALERTE') || m.type.includes('NON_AUTORISÉE');

      return `
        <tr class="hover:bg-slate-50 transition border-b border-slate-100 ${isSuspect ? 'bg-red-50/70' : ''}">
          <td class="py-3 px-4 text-xs font-mono text-slate-500">
            ${new Date(m.timestamp).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            <div class="text-[10px] text-slate-400">${new Date(m.timestamp).toLocaleDateString('fr-FR')}</div>
          </td>
          <td class="py-3 px-4 text-xs">
            <span class="font-bold text-slate-800">${m.designation}</span>
            <div class="text-[11px] text-slate-500 font-mono">Réf: ${m.sku} | Qte: <strong>${m.qty}</strong> (${m.weightKg} kg)</div>
          </td>
          <td class="py-3 px-4 text-xs">
            <div class="text-slate-700"><i class="fa-solid fa-user-shield text-slate-400 mr-1"></i>${m.operatorId}</div>
            <div class="text-[10px] font-mono text-slate-500">Badge: ${m.badgeId}</div>
          </td>
          <td class="py-3 px-4 text-xs font-mono">
            <span class="${m.exitAuthNumber.includes('AUCUN') ? 'text-red-600 font-black' : 'text-emerald-700 font-bold'}">
              ${m.exitAuthNumber}
            </span>
          </td>
          <td class="py-3 px-4">
            ${isSuspect ? `
              <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-black bg-red-600 text-white animate-pulse">
                <i class="fa-solid fa-triangle-exclamation"></i> SORTIE ILLICITE
              </span>
            ` : `
              <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-100 text-emerald-800">
                <i class="fa-solid fa-circle-check"></i> Autorisé
              </span>
            `}
          </td>
        </tr>
      `;
    }).join('');
  },

  // Audit détaillé d'un écart sur un SKU
  inspectStockDiscrepancy(sku) {
    const item = TRACE_DATA.inventoryItems.find(i => i.sku === sku);
    if (!item) return;

    const modal = document.getElementById('stockAuditModal');
    const content = document.getElementById('stockAuditContent');
    if (!modal || !content) return;

    const qtyDiff = item.physicalQty - item.theoreticalQty;
    const avgUnitWeight = item.theoreticalWeightKg / item.theoreticalQty;
    const lossValue = qtyDiff < 0 ? Math.abs(qtyDiff) * avgUnitWeight * item.pricePerKg : 0;

    content.innerHTML = `
      <div class="space-y-4">
        <div class="flex justify-between items-start border-b pb-3">
          <div>
            <h3 class="text-base font-bold text-slate-900">${item.designation}</h3>
            <p class="text-xs text-slate-500 font-mono">SKU : ${item.sku} | Valeur marchande : ${item.pricePerKg.toFixed(2)} € / kg</p>
          </div>
          <span class="px-2.5 py-1 rounded-full text-xs font-bold ${item.status === 'SUSPICION_VOL' ? 'bg-red-600 text-white' : 'bg-emerald-100 text-emerald-800'}">
            ${item.status}
          </span>
        </div>

        <!-- Diagnostic Anti-Vol -->
        <div class="bg-slate-50 p-4 rounded-xl border border-slate-200 grid grid-cols-2 gap-4 text-xs">
          <div>
            <span class="text-slate-500">Stock Théorique (Factures & Abattages) :</span>
            <div class="text-sm font-bold text-slate-900">${item.theoreticalQty} ${item.unit} (${item.theoreticalWeightKg} kg)</div>
          </div>
          <div>
            <span class="text-slate-500">Stock Réel Physique (Comptage SAS) :</span>
            <div class="text-sm font-bold ${qtyDiff < 0 ? 'text-red-600' : 'text-emerald-700'}">${item.physicalQty} ${item.unit} (${item.physicalWeightKg} kg)</div>
          </div>
          <div>
            <span class="text-slate-500">Écart Détecté :</span>
            <div class="text-sm font-black ${qtyDiff < 0 ? 'text-red-600' : 'text-slate-700'}">${qtyDiff} ${item.unit}</div>
          </div>
          <div>
            <span class="text-slate-500">Préjudice Financier Direct :</span>
            <div class="text-base font-black text-red-600">-${lossValue.toFixed(2)} €</div>
          </div>
        </div>

        <!-- Analyse du coulage (Ressuage naturel vs Vol) -->
        <div class="bg-white p-3 rounded-lg border border-slate-200 text-xs space-y-2">
          <h4 class="font-bold text-slate-800 flex items-center gap-1.5">
            <i class="fa-solid fa-scale-unbalanced text-amber-600"></i>
            Diagnostic de Ressuage & Évaporation
          </h4>
          <p class="text-slate-600 leading-relaxed text-[11px]">
            La tolérance biologique normale d'évaporation d'eau pour cette référence est de <strong>${item.normalShrinkagePct}%</strong>.
            La perte observée lors du dernier pesage est de <strong class="${item.measuredLossPct > item.normalShrinkagePct ? 'text-red-600' : 'text-emerald-700'}">${item.measuredLossPct}%</strong>.
            ${item.measuredLossPct > item.normalShrinkagePct 
              ? `<span class="block text-red-700 font-semibold mt-1">⚠️ L'écart excède la limite biologique. Il s'agit d'une perte physique inexpliquée (coulage / soustraction illicite).</span>`
              : `<span class="block text-emerald-700 font-semibold mt-1">✅ L'écart de poids s'explique totalement par la perte d'eau normale en chambre froide.</span>`
            }
          </p>
        </div>

        <!-- Puces RFID affectées -->
        <div class="text-xs space-y-1">
          <span class="font-bold text-slate-700">Tags RFID / Numéros de séries surveillés :</span>
          <div class="flex flex-wrap gap-1">
            ${item.rfidTags.map(t => `
              <span class="bg-slate-100 text-slate-700 border font-mono px-2 py-0.5 rounded text-[10px]">${t}</span>
            `).join('')}
          </div>
        </div>

        <!-- Actions de sécurisation -->
        <div class="flex justify-between items-center pt-3 border-t">
          <button onclick="StockManager.generateTheftReport('${item.sku}')" class="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded text-xs font-bold flex items-center gap-1">
            <i class="fa-solid fa-file-shield"></i> Exporter Rapport de Vol pour Dépôt de Plainte
          </button>
          <button onclick="StockManager.closeModal('stockAuditModal')" class="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded text-xs font-semibold">
            Fermer
          </button>
        </div>
      </div>
    `;

    modal.classList.remove('hidden');
  },

  // Simuler un inventaire RFID express en direct
  runLiveRFIDInventory() {
    if (window.App) {
      window.App.showNotification("Démarrage du scan RFID express des chambres froides...", "info");
    }

    setTimeout(() => {
      // Met à jour les effectifs scannés
      TRACE_DATA.inventoryItems.forEach(item => {
        // Aléatoire contrôlé pour la démo
        if (item.sku === 'BOV-NOB-FILET') {
          item.physicalQty = 29; // persiste le vol
        }
      });

      this.renderInventoryTable();
      if (window.App) {
        window.App.showNotification("Inventaire RFID terminé : 2 anomalies critiques de coulage identifiées !", "error");
      }
    }, 1200);
  },

  // Enregistrer un nouveau mouvement sécurisé
  recordMovement(formData) {
    const newMvt = {
      id: `MVT-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      timestamp: new Date().toISOString(),
      operatorId: formData.operator,
      badgeId: formData.badge || "RFID-AUTO-SCAN",
      sku: formData.sku,
      designation: formData.designation,
      type: formData.type,
      qty: parseInt(formData.qty, 10),
      weightKg: parseFloat(formData.weight),
      sourceLocation: formData.source,
      targetLocation: formData.target,
      exitAuthNumber: formData.exitAuth ? formData.exitAuth : "SANS_BON_EXPEDITION",
      status: formData.exitAuth ? "AUTORISÉ_CONFORME" : "ALERTE_VOL_DÉCLENCHÉE"
    };

    TRACE_DATA.stockMovements.unshift(newMvt);

    // Mettre à jour l'inventaire physique
    const item = TRACE_DATA.inventoryItems.find(i => i.sku === formData.sku);
    if (item) {
      if (formData.type.includes('SORTIE') || formData.type.includes('EXPÉDITION')) {
        item.physicalQty -= newMvt.qty;
        item.physicalWeightKg -= newMvt.weightKg;
      } else if (formData.type.includes('ENTRÉE')) {
        item.physicalQty += newMvt.qty;
        item.physicalWeightKg += newMvt.weightKg;
      }
    }

    this.renderInventoryTable();
    this.renderMovementsTable();

    if (window.App) {
      if (newMvt.status === "ALERTE_VOL_DÉCLENCHÉE") {
        window.App.showNotification("ALERTE : Sortie bloquée sans Bon de Commande / Expédition !", "error");
      } else {
        window.App.showNotification("Mouvement de stock enregistré avec succès.", "success");
      }
    }
  },

  generateTheftReport(sku) {
    const item = TRACE_DATA.inventoryItems.find(i => i.sku === sku);
    if (!item) return;

    alert(`RAPPORT D'ANOMALIE & VOL GÉNÉRÉ :
---------------------------------------------
Référence : ${item.designation} (${item.sku})
Écart physique : ${item.theoreticalQty - item.physicalQty} pièces dérobées
Préjudice financier estimé : ${( (item.theoreticalQty - item.physicalQty) * (item.theoreticalWeightKg / item.theoreticalQty) * item.pricePerKg ).toFixed(2)} €
Rapport horodaté transmis à la direction et au service sécurité.`);
  },

  closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.add('hidden');
  }
};

window.StockManager = StockManager;
