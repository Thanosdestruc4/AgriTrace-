/**
 * Contrôleur Principal - Application Web de Traçabilité de Viande
 */

const App = {
  currentTab: 'dashboard',
  selectedSpecies: 'all',
  activeConsumerLot: 'LOT-BOV-2026-884',

  init() {
    this.bindEvents();
    this.renderStats();
    this.renderLotsTable();
    this.renderFarms();
    this.renderConsumerView(this.activeConsumerLot);
    this.renderLabel(this.activeConsumerLot);

    // Initialiser le module Gestion des Stocks & Anti-Vol
    if (window.StockManager) {
      StockManager.init();
    }

    // Initialiser le module IoT avec Chart.js
    if (window.IoTSimulator) {
      setTimeout(() => {
        IoTSimulator.init('iotChartCanvas');
      }, 300);
    }
  },

  bindEvents() {
    // Navigation onglets
    document.querySelectorAll('[data-nav]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const target = e.currentTarget.getAttribute('data-nav');
        this.switchTab(target);
      });
    });

    // Filtre d'espèce
    const speciesFilter = document.getElementById('speciesFilter');
    if (speciesFilter) {
      speciesFilter.addEventListener('change', (e) => {
        this.selectedSpecies = e.target.value;
        this.renderLotsTable();
      });
    }
  },

  switchTab(tabId) {
    this.currentTab = tabId;

    // Mise à jour de la classe active des boutons
    document.querySelectorAll('[data-nav]').forEach(btn => {
      const active = btn.getAttribute('data-nav') === tabId;
      btn.classList.toggle('bg-emerald-800', active);
      btn.classList.toggle('text-white', active);
      btn.classList.toggle('text-emerald-100', !active);
      btn.classList.toggle('hover:bg-emerald-800/60', !active);
    });

    // Affichage des sections
    document.querySelectorAll('.tab-content').forEach(section => {
      section.classList.toggle('hidden', section.id !== `tab-${tabId}`);
    });

    if (tabId === 'stock' && window.StockManager) {
      StockManager.renderInventoryTable();
      StockManager.renderStockKPIs();
      StockManager.renderMovementsTable();
    }

    if (tabId === 'iot' && window.IoTSimulator) {
      setTimeout(() => {
        IoTSimulator.selectSensor(IoTSimulator.activeSensorId);
      }, 100);
    }
  },

  showNotification(message, type = 'info') {
    const toast = document.getElementById('toastNotification');
    const toastText = document.getElementById('toastText');
    const toastIcon = document.getElementById('toastIcon');

    if (!toast || !toastText) return;

    toastText.textContent = message;

    toast.className = "fixed bottom-5 right-5 z-50 flex items-center gap-3 px-4 py-3 rounded-xl shadow-2xl transition-all duration-300 text-sm font-medium text-white border ";
    if (type === 'error') {
      toast.classList.add('bg-red-700', 'border-red-500');
      toastIcon.innerHTML = `<i class="fa-solid fa-triangle-exclamation text-lg"></i>`;
    } else if (type === 'success') {
      toast.classList.add('bg-emerald-700', 'border-emerald-500');
      toastIcon.innerHTML = `<i class="fa-solid fa-circle-check text-lg"></i>`;
    } else {
      toast.classList.add('bg-slate-800', 'border-slate-600');
      toastIcon.innerHTML = `<i class="fa-solid fa-bell text-lg"></i>`;
    }

    toast.classList.remove('opacity-0', 'translate-y-4', 'pointer-events-none');
    setTimeout(() => {
      toast.classList.add('opacity-0', 'translate-y-4', 'pointer-events-none');
    }, 4500);
  },

  renderStats() {
    const totalLots = TRACE_DATA.lots.length;
    const recalledLots = TRACE_DATA.lots.filter(l => l.status === "RAPPEL_IMMEDIAT").length;
    const tempAlerts = TRACE_DATA.lots.filter(l => l.coldChainAlert || l.currentTemp > 4.0).length;
    const totalFarms = TRACE_DATA.stakeholders.filter(s => s.type.includes("Élevage")).length;

    const elTotal = document.getElementById('kpiTotalLots');
    const elRecalled = document.getElementById('kpiRecalledLots');
    const elTempAlerts = document.getElementById('kpiTempAlerts');
    const elTotalFarms = document.getElementById('kpiTotalFarms');

    if (elTotal) elTotal.textContent = totalLots;
    if (elRecalled) {
      elRecalled.textContent = recalledLots;
      elRecalled.parentElement.classList.toggle('bg-red-50', recalledLots > 0);
      elRecalled.classList.toggle('text-red-600', recalledLots > 0);
    }
    if (elTempAlerts) {
      elTempAlerts.textContent = tempAlerts;
      elTempAlerts.parentElement.classList.toggle('bg-amber-50', tempAlerts > 0);
      elTempAlerts.classList.toggle('text-amber-600', tempAlerts > 0);
    }
    if (elTotalFarms) elTotalFarms.textContent = totalFarms;
  },

  renderLotsTable() {
    const tbody = document.getElementById('lotsTableBody');
    if (!tbody) return;

    const filteredLots = TRACE_DATA.lots.filter(lot => {
      if (this.selectedSpecies === 'all') return true;
      return lot.species.toLowerCase() === this.selectedSpecies.toLowerCase();
    });

    tbody.innerHTML = filteredLots.map(lot => {
      const isRecalled = lot.status === "RAPPEL_IMMEDIAT";
      const hasTempAlert = lot.coldChainAlert || lot.currentTemp > 4.0;
      const farm = TRACE_DATA.stakeholders.find(s => s.id === lot.farmId);

      let speciesBadgeColor = "bg-blue-100 text-blue-800 border-blue-200";
      if (lot.species === "Bovin") speciesBadgeColor = "bg-amber-100 text-amber-900 border-amber-200";
      if (lot.species === "Porcin") speciesBadgeColor = "bg-rose-100 text-rose-800 border-rose-200";
      if (lot.species === "Volaille") speciesBadgeColor = "bg-emerald-100 text-emerald-800 border-emerald-200";
      if (lot.species === "Ovin") speciesBadgeColor = "bg-purple-100 text-purple-800 border-purple-200";

      return `
        <tr class="hover:bg-slate-50 transition border-b border-slate-100 ${isRecalled ? 'bg-red-50/70' : ''}">
          <td class="py-3 px-4">
            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border ${speciesBadgeColor}">
              ${lot.species}
            </span>
          </td>
          <td class="py-3 px-4 font-mono font-medium text-slate-800 text-sm">
            ${lot.lotNumber}
            <div class="text-[11px] text-slate-500 font-sans">${lot.productName}</div>
          </td>
          <td class="py-3 px-4 text-xs text-slate-700">
            <div class="font-medium">${farm ? farm.name : 'Inconnu'}</div>
            <div class="text-[11px] text-slate-500 font-mono">ID: ${lot.animalId}</div>
          </td>
          <td class="py-3 px-4 text-xs text-slate-600">
            <div>Emb: ${lot.packagingDate}</div>
            <div>DLC: <span class="font-medium text-slate-800">${lot.expiryDate}</span></div>
          </td>
          <td class="py-3 px-4 text-xs">
            <span class="inline-flex items-center gap-1 font-mono font-semibold px-2 py-0.5 rounded ${hasTempAlert ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-700'}">
              <i class="fa-solid fa-temperature-half"></i> ${lot.currentTemp}°C
            </span>
          </td>
          <td class="py-3 px-4">
            ${isRecalled 
              ? `<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-red-600 text-white animate-pulse">
                  <i class="fa-solid fa-triangle-exclamation"></i> RAPPEL ACTIF
                 </span>`
              : `<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">
                  <i class="fa-solid fa-check-circle"></i> Conforme
                 </span>`
            }
          </td>
          <td class="py-3 px-4 text-right">
            <div class="inline-flex items-center gap-1">
              <button onclick="App.inspectLot('${lot.lotNumber}')" class="px-2 py-1 bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 text-xs rounded shadow-sm font-medium" title="Fiche détaillée">
                <i class="fa-regular fa-eye"></i> Fiche
              </button>
              <button onclick="App.openLabelModal('${lot.lotNumber}')" class="px-2 py-1 bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 text-xs rounded shadow-sm font-medium" title="Étiquette GS1">
                <i class="fa-solid fa-barcode"></i> Étiquette
              </button>
              <button onclick="App.openConsumerView('${lot.lotNumber}')" class="px-2 py-1 bg-emerald-700 hover:bg-emerald-800 text-white text-xs rounded shadow-sm font-medium" title="Scan Consommateur">
                <i class="fa-solid fa-qrcode"></i> Scan
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');

    this.renderStats();
  },

  renderFarms() {
    const container = document.getElementById('farmsGrid');
    if (!container) return;

    const farms = TRACE_DATA.stakeholders.filter(s => s.type.includes("Élevage"));
    container.innerHTML = farms.map(f => `
      <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-md transition">
        <div class="h-36 bg-cover bg-center relative" style="background-image: url('${f.photo}')">
          <div class="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent"></div>
          <span class="absolute top-3 left-3 bg-white/90 backdrop-blur-sm px-2.5 py-0.5 rounded-full text-[11px] font-semibold text-emerald-900">
            ${f.type}
          </span>
          <span class="absolute bottom-2 left-3 text-white font-bold text-base">
            ${f.name}
          </span>
        </div>
        <div class="p-4 space-y-2 text-xs">
          <div class="flex items-center gap-2 text-slate-600">
            <i class="fa-solid fa-user-tie text-emerald-700 w-4"></i>
            <span>Responsable : <strong>${f.manager}</strong></span>
          </div>
          <div class="flex items-center gap-2 text-slate-600">
            <i class="fa-solid fa-location-dot text-emerald-700 w-4"></i>
            <span>${f.address}</span>
          </div>
          <div class="flex items-center gap-2 text-slate-600">
            <i class="fa-solid fa-stethoscope text-emerald-700 w-4"></i>
            <span>Vétérinaire : ${f.veterinarian}</span>
          </div>
          <div class="pt-2 border-t border-slate-100">
            <p class="text-slate-500 font-semibold mb-1">Régime & Pâturage :</p>
            <p class="text-slate-700 bg-slate-50 p-2 rounded text-[11px] italic leading-relaxed">${f.diet}</p>
          </div>
          <div class="flex flex-wrap gap-1 pt-1">
            ${f.certifications.map(c => `
              <span class="bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded text-[10px] font-medium">
                <i class="fa-solid fa-award mr-1"></i>${c}
              </span>
            `).join('')}
          </div>
        </div>
      </div>
    `).join('');
  },

  inspectLot(lotNumber) {
    const chain = RecallEngine.getCompleteTraceChain(lotNumber);
    if (!chain) return;

    const modal = document.getElementById('lotDetailModal');
    const content = document.getElementById('lotDetailContent');
    if (!modal || !content) return;

    content.innerHTML = `
      <div class="space-y-4">
        <!-- En-tête -->
        <div class="flex items-center justify-between border-b pb-3">
          <div>
            <h3 class="text-lg font-bold text-slate-900">${chain.lot.productName}</h3>
            <p class="text-xs text-slate-500 font-mono">Lot : ${chain.lot.lotNumber} | GTIN : ${chain.lot.gtin}</p>
          </div>
          <span class="px-3 py-1 rounded-full text-xs font-bold ${chain.lot.status === 'RAPPEL_IMMEDIAT' ? 'bg-red-600 text-white' : 'bg-emerald-100 text-emerald-800'}">
            ${chain.lot.status}
          </span>
        </div>

        <!-- Timeline Traçabilité EPCIS -->
        <div class="relative border-l-2 border-emerald-600 ml-4 pl-4 space-y-4 text-xs">
          <!-- 1. Élevage -->
          <div class="relative">
            <div class="absolute -left-[23px] top-0 w-3 h-3 rounded-full bg-emerald-600 ring-4 ring-white"></div>
            <h4 class="font-bold text-slate-800">1. Élevage & Naissance</h4>
            <p class="text-slate-600">${chain.farm.name} (${chain.farm.address})</p>
            <p class="text-slate-500 mt-1">Identifiant animal : <strong>${chain.lot.animalId}</strong> | Race : ${chain.lot.breed}</p>
            <p class="text-slate-500">Né le : ${chain.lot.birthDate} | Sexe/Type : ${chain.lot.gender}</p>
          </div>

          <!-- 2. Abattage -->
          <div class="relative">
            <div class="absolute -left-[23px] top-0 w-3 h-3 rounded-full bg-emerald-600 ring-4 ring-white"></div>
            <h4 class="font-bold text-slate-800">2. Abattage & Contrôle Vétérinaire</h4>
            <p class="text-slate-600">${chain.slaughterhouse.name} (Agrément : ${chain.slaughterhouse.sanitaryNumber})</p>
            <p class="text-slate-500 mt-1">Date d'abattage : ${chain.lot.slaughterDate} | N° de tuerie : <strong>${chain.lot.slaughterNumber}</strong></p>
            <p class="text-slate-500">Poids carcasse : ${chain.lot.carcassWeight} kg | Classement EUROP : <strong>${chain.lot.carcassEuropClass}</strong> | pH : ${chain.lot.phValue}</p>
          </div>

          <!-- 3. Découpe & Conditionnement -->
          <div class="relative">
            <div class="absolute -left-[23px] top-0 w-3 h-3 rounded-full bg-emerald-600 ring-4 ring-white"></div>
            <h4 class="font-bold text-slate-800">3. Atelier de Découpe</h4>
            <p class="text-slate-600">${chain.cuttingPlant.name} (Agrément : ${chain.cuttingPlant.sanitaryNumber})</p>
            <p class="text-slate-500 mt-1">Conditionné le : ${chain.lot.packagingDate} | DLC : <strong>${chain.lot.expiryDate}</strong></p>
          </div>

          <!-- 4. Chaîne du froid & Distribution -->
          <div class="relative">
            <div class="absolute -left-[23px] top-0 w-3 h-3 rounded-full bg-emerald-600 ring-4 ring-white"></div>
            <h4 class="font-bold text-slate-800">4. Acheminement & Point de Vente</h4>
            <p class="text-slate-600">${chain.distributor.name} (${chain.distributor.address})</p>
            <p class="text-slate-500 mt-1">Température relevée : <strong class="text-emerald-700">${chain.lot.currentTemp}°C</strong> (Plage autorisée : ${chain.lot.temperatureTarget})</p>
          </div>
        </div>

        <!-- Empreinte Cryptographique d'Immuabilité -->
        <div class="bg-slate-900 text-slate-200 p-3 rounded-lg text-xs font-mono">
          <div class="flex items-center justify-between text-emerald-400 font-bold mb-1">
            <span><i class="fa-solid fa-shield-halved mr-1"></i> Preuve d'Intégrité / Blockchain Hash</span>
            <span class="text-[10px] bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">BLOC #${chain.blockchainAuditProof.blockNumber}</span>
          </div>
          <div class="text-[11px] truncate text-slate-400">Racine Merkle : ${chain.blockchainAuditProof.merkleRoot}</div>
          <div class="text-[10px] text-slate-400 mt-1">Horodatage certifié UTC : ${chain.blockchainAuditProof.recordedAt}</div>
        </div>
      </div>
    `;

    modal.classList.remove('hidden');
  },

  closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.add('hidden');
  },

  openLabelModal(lotNumber) {
    this.renderLabel(lotNumber);
    const modal = document.getElementById('labelPrintModal');
    if (modal) modal.classList.remove('hidden');
  },

  renderLabel(lotNumber) {
    const lot = TRACE_DATA.lots.find(l => l.lotNumber === lotNumber);
    if (!lot) return;

    const farm = TRACE_DATA.stakeholders.find(s => s.id === lot.farmId);
    const slaughterhouse = TRACE_DATA.stakeholders.find(s => s.id === lot.slaughterhouseId);
    const cuttingPlant = TRACE_DATA.stakeholders.find(s => s.id === lot.cuttingPlantId);

    const labelBox = document.getElementById('printableMeatLabel');
    if (!labelBox) return;

    const qrContainer = MeatQR.render(lot.digitalLink, 110);

    labelBox.innerHTML = `
      <div class="border-2 border-black p-4 bg-white text-black font-sans w-full max-w-md mx-auto shadow-sm select-none">
        <div class="flex justify-between items-start border-b-2 border-black pb-2 mb-2">
          <div>
            <h2 class="text-lg font-black uppercase tracking-tight">${lot.productName}</h2>
            <p class="text-xs font-bold text-slate-800">${lot.cutType}</p>
          </div>
          <div class="border border-black px-2 py-0.5 text-center text-[10px] font-black uppercase">
            ${cuttingPlant.sanitaryNumber}
          </div>
        </div>

        <div class="grid grid-cols-3 gap-2 border-b border-black pb-2 mb-2 text-xs">
          <div>
            <span class="block text-[9px] uppercase font-bold text-slate-600">Poids Net</span>
            <span class="font-black text-sm">${lot.weightKg} kg</span>
          </div>
          <div>
            <span class="block text-[9px] uppercase font-bold text-slate-600">Date Emballage</span>
            <span class="font-semibold">${lot.packagingDate}</span>
          </div>
          <div>
            <span class="block text-[9px] uppercase font-bold text-slate-600">À Consommer Jusqu'au</span>
            <span class="font-black text-sm text-black">${lot.expiryDate}</span>
          </div>
        </div>

        <!-- Mentions légales réglementaires (CE 1760/2000) -->
        <div class="bg-slate-100 p-2 text-[11px] space-y-0.5 border border-slate-300 mb-2">
          <div><strong class="font-bold">Né en :</strong> FRANCE (Dép. ${farm.address.match(/\\d{2}/) ? farm.address.match(/\\d{2}/)[0] : '71'})</div>
          <div><strong class="font-bold">Élevé en :</strong> FRANCE (${farm.name})</div>
          <div><strong class="font-bold">Abattu en :</strong> FRANCE (${slaughterhouse.sanitaryNumber} - N° Tuerie ${lot.slaughterNumber})</div>
          <div><strong class="font-bold">Découpé en :</strong> FRANCE (${cuttingPlant.sanitaryNumber})</div>
          <div><strong class="font-bold">N° Identification Animal :</strong> <span class="font-mono font-bold">${lot.animalId}</span></div>
          <div><strong class="font-bold">N° de Lot :</strong> <span class="font-mono font-black">${lot.lotNumber}</span></div>
        </div>

        <div class="flex items-center justify-between pt-1">
          <div class="space-y-1">
            <div class="text-[10px] font-mono">GTIN: ${lot.gtin}</div>
            <div class="text-[9px] text-slate-600 italic">Conserver entre ${lot.temperatureTarget}</div>
            <div class="text-[10px] font-bold text-emerald-900 flex items-center gap-1">
              <i class="fa-solid fa-leaf"></i> Scannez pour voir l'éleveur
            </div>
          </div>
          <div class="w-24 h-24 flex items-center justify-center">
            ${qrContainer}
          </div>
        </div>
      </div>
    `;
  },

  openConsumerView(lotNumber) {
    this.activeConsumerLot = lotNumber;
    this.renderConsumerView(lotNumber);
    this.switchTab('consumer');
  },

  renderConsumerView(lotNumber) {
    const lot = TRACE_DATA.lots.find(l => l.lotNumber === lotNumber);
    if (!lot) return;

    const farm = TRACE_DATA.stakeholders.find(s => s.id === lot.farmId);
    const slaughterhouse = TRACE_DATA.stakeholders.find(s => s.id === lot.slaughterhouseId);
    const cuttingPlant = TRACE_DATA.stakeholders.find(s => s.id === lot.cuttingPlantId);

    const container = document.getElementById('consumerPhoneScreen');
    if (!container) return;

    const isRecalled = lot.status === "RAPPEL_IMMEDIAT";

    if (isRecalled) {
      container.innerHTML = `
        <div class="h-full bg-red-600 text-white flex flex-col justify-between p-6 animate-pulse">
          <div class="text-center pt-8">
            <i class="fa-solid fa-triangle-exclamation text-6xl text-white mb-4"></i>
            <h2 class="text-2xl font-black uppercase tracking-wider mb-2">PRODUIT SOUS RAPPEL</h2>
            <p class="text-sm font-semibold bg-red-800/80 p-3 rounded-lg border border-red-400">
              NE PAS CONSOMMER CE PRODUIT
            </p>
          </div>

          <div class="bg-white text-slate-900 rounded-xl p-4 shadow-lg text-xs space-y-2">
            <div class="font-bold text-red-700 text-sm border-b pb-1">Avis Officiel de Sécurité Sanitaire</div>
            <p><strong>Lot concerné :</strong> ${lot.lotNumber}</p>
            <p><strong>Produit :</strong> ${lot.productName}</p>
            <p><strong>Motif :</strong> ${lot.recallReason || "Mesure de précaution sanitaire DDPP"}</p>
            <p class="text-[11px] text-slate-600">Veuillez rapporter cette barquette au point de vente pour remboursement immédiat.</p>
          </div>

          <div class="text-center pb-4 text-xs text-red-200">
            Plateforme Nationale de Traçabilité Sanitaire
          </div>
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <!-- En-tête photo ferme -->
      <div class="relative h-44 bg-cover bg-center" style="background-image: url('${farm.photo}')">
        <div class="absolute inset-0 bg-gradient-to-t from-emerald-950 via-emerald-950/40 to-transparent"></div>
        <div class="absolute top-3 left-3 bg-emerald-700/90 backdrop-blur text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
          <i class="fa-solid fa-shield-halved mr-1"></i> Origine 100% Vérifiée
        </div>
        <div class="absolute bottom-3 left-3 right-3 text-white">
          <span class="text-[11px] uppercase tracking-wider text-emerald-300 font-semibold">${lot.species} - ${farm.name}</span>
          <h2 class="text-lg font-black leading-tight">${lot.productName}</h2>
        </div>
      </div>

      <!-- Corps défilant du smartphone -->
      <div class="p-4 space-y-4 text-xs overflow-y-auto max-h-[460px] pb-12">
        <!-- Labels & Certifications -->
        <div class="flex flex-wrap gap-1">
          ${lot.certifications.map(c => `
            <span class="bg-emerald-50 text-emerald-800 border border-emerald-200 font-semibold px-2 py-0.5 rounded-full text-[10px]">
              <i class="fa-solid fa-check text-emerald-600 mr-1"></i>${c}
            </span>
          `).join('')}
        </div>

        <!-- Fiche de l'éleveur -->
        <div class="bg-emerald-50/70 border border-emerald-200 rounded-xl p-3 space-y-1.5">
          <div class="flex items-center gap-2">
            <div class="w-8 h-8 rounded-full bg-emerald-700 text-white flex items-center justify-center font-bold text-xs">
              <i class="fa-solid fa-tractor"></i>
            </div>
            <div>
              <div class="font-bold text-slate-800 text-xs">${farm.manager}</div>
              <div class="text-[11px] text-slate-500">${farm.address}</div>
            </div>
          </div>
          <p class="text-[11px] text-slate-600 italic bg-white p-2 rounded border border-emerald-100">
            "${farm.diet}"
          </p>
        </div>

        <!-- Carte d'identité de l'animal -->
        <div class="bg-white rounded-xl border border-slate-200 p-3 shadow-sm space-y-1">
          <h4 class="font-bold text-slate-800 text-xs flex items-center gap-1 text-emerald-800">
            <i class="fa-solid fa-id-card"></i> Identité de l'animal
          </h4>
          <div class="grid grid-cols-2 gap-2 pt-1 text-[11px]">
            <div><span class="text-slate-500">Numéro national :</span> <br><strong class="font-mono text-slate-800">${lot.animalId}</strong></div>
            <div><span class="text-slate-500">Race :</span> <br><strong class="text-slate-800">${lot.breed}</strong></div>
            <div><span class="text-slate-500">Naissance :</span> <br><strong class="text-slate-800">${lot.birthDate}</strong></div>
            <div><span class="text-slate-500">Abattage :</span> <br><strong class="text-slate-800">${lot.slaughterDate}</strong></div>
          </div>
        </div>

        <!-- Étapes du parcours de la viande -->
        <div class="bg-white rounded-xl border border-slate-200 p-3 shadow-sm space-y-2">
          <h4 class="font-bold text-slate-800 text-xs text-emerald-800 flex items-center gap-1">
            <i class="fa-solid fa-route"></i> Parcours garanti "Farm to Fork"
          </h4>
          <div class="space-y-2 text-[11px] pl-2 border-l-2 border-emerald-500">
            <div>
              <div class="font-semibold text-slate-800">1. Élevage pastoral</div>
              <div class="text-slate-500">${farm.name}</div>
            </div>
            <div>
              <div class="font-semibold text-slate-800">2. Abattoir agréé CE</div>
              <div class="text-slate-500">${slaughterhouse.name} (${slaughterhouse.sanitaryNumber})</div>
            </div>
            <div>
              <div class="font-semibold text-slate-800">3. Atelier de découpe</div>
              <div class="text-slate-500">${cuttingPlant.name}</div>
            </div>
            <div>
              <div class="font-semibold text-slate-800">4. Chaîne du froid sous contrôle</div>
              <div class="text-emerald-700 font-semibold"><i class="fa-solid fa-temperature-arrow-down mr-1"></i> Contrôlée à ${lot.currentTemp}°C</div>
            </div>
          </div>
        </div>

        <!-- Conseils du boucher & Recette -->
        <div class="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs space-y-1">
          <h4 class="font-bold text-amber-900 flex items-center gap-1">
            <i class="fa-solid fa-utensils"></i> Le Conseil du Maître Boucher
          </h4>
          <p class="text-[11px] text-amber-950">${lot.consumerTips.preparation}</p>
          <div class="text-[10px] text-amber-800 font-medium pt-1 border-t border-amber-200">
            <strong>Accord parfait :</strong> ${lot.consumerTips.pairing}
          </div>
        </div>
      </div>
    `;
  },

  // Simuler une urgence sanitaire sur le lot actuellement affiché
  simulateCrisisOnCurrentLot() {
    const lotNumber = this.activeConsumerLot;
    const result = RecallEngine.triggerRecall(lotNumber, "Présence de toxine Shiga (STEC) détectée lors du contrôle microbiologique libératoire DDPP");

    if (result) {
      this.renderLotsTable();
      this.renderConsumerView(lotNumber);
      this.showNotification(`ALERTE SANITAIRE : Rappel immédiat déclenché sur ${result.affectedLotsCount} lot(s) !`, "error");

      // Basculer vers l'onglet de gestion de crise
      this.switchTab('crisis');
      this.renderCrisisReport(result);
    }
  },

  renderCrisisReport(result) {
    const reportBox = document.getElementById('crisisReportContainer');
    if (!reportBox) return;

    reportBox.innerHTML = `
      <div class="bg-red-50 border-2 border-red-500 rounded-xl p-5 space-y-4">
        <div class="flex items-center justify-between border-b border-red-200 pb-3">
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-full bg-red-600 text-white flex items-center justify-center text-lg">
              <i class="fa-solid fa-radiation"></i>
            </div>
            <div>
              <h3 class="text-base font-bold text-red-900">Procédure d'Urgence Sanitaire Activée</h3>
              <p class="text-xs text-red-700">Déclenchée le ${new Date(result.triggeredAt).toLocaleString('fr-FR')}</p>
            </div>
          </div>
          <button onclick="App.cancelCrisis('${result.primaryLot}')" class="px-3 py-1 bg-white border border-red-300 text-red-700 hover:bg-red-100 rounded text-xs font-semibold">
            Lever le rappel
          </button>
        </div>

        <div class="text-xs space-y-2 text-slate-800">
          <p><strong>Motif légal :</strong> ${result.reason}</p>
          <p><strong>Lots bloqués dans l'arbre généalogique (${result.affectedLotsCount}) :</strong></p>
          <div class="space-y-1">
            ${result.distributorsToAlert.map(d => `
              <div class="bg-white p-2.5 rounded border border-red-200 flex justify-between items-center">
                <div>
                  <span class="font-mono font-bold text-red-700">${d.lotNumber}</span> - ${d.productName}
                  <div class="text-[11px] text-slate-500">Destinataire : <strong>${d.distributor}</strong> (${d.address})</div>
                </div>
                <span class="bg-red-600 text-white text-[10px] font-bold px-2 py-1 rounded uppercase">
                  ${d.status}
                </span>
              </div>
            `).join('')}
          </div>
        </div>

        <div class="bg-white p-3 rounded border border-red-200 text-xs flex items-center justify-between">
          <div class="text-slate-600">
            <i class="fa-solid fa-file-pdf text-red-600 mr-1"></i> Fiche CERFA / RappelConso générée automatiquement pour la DDPP
          </div>
          <button onclick="alert('Export PDF officiel généré avec succès !')" class="px-3 py-1 bg-red-700 hover:bg-red-800 text-white rounded text-xs font-semibold">
            Télécharger Dossier Rappel
          </button>
        </div>
      </div>
    `;
  },

  cancelCrisis(lotNumber) {
    RecallEngine.clearRecall(lotNumber);
    // Réinitialiser les autres lots
    TRACE_DATA.lots.forEach(l => {
      RecallEngine.clearRecall(l.lotNumber);
    });

    this.renderLotsTable();
    this.renderConsumerView(lotNumber);
    this.showNotification("Rappel de lot levé. Statut conforme restauré.", "success");

    const reportBox = document.getElementById('crisisReportContainer');
    if (reportBox) {
      reportBox.innerHTML = `
        <div class="text-center py-12 text-slate-400 bg-white rounded-xl border border-slate-200">
          <i class="fa-solid fa-shield-check text-4xl text-emerald-500 mb-2"></i>
          <p class="text-sm font-semibold text-slate-700">Aucune alerte sanitaire active</p>
          <p class="text-xs text-slate-500 mt-1">Tous les lots en circulation sont conformes aux analyses vétérinaires.</p>
        </div>
      `;
    }
  }
};

window.App = App;
document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
