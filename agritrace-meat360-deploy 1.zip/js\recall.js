/**
 * Moteur de Traçabilité Ascendante / Descendante et Gestion de Crise Sanitaire (Mock Recall)
 * Conforme aux exigences du Paquet Hygiène & DDPP
 */

const RecallEngine = {
  // Calcul de hachage SHA-256 simulé / cryptographique pour l'audit trail
  async calculateHash(dataString) {
    if (window.crypto && window.crypto.subtle) {
      const msgBuffer = new TextEncoder().encode(dataString);
      const hashBuffer = await window.crypto.subtle.digest('SHA-256', msgBuffer);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    }
    // Fallback simple si crypto n'est pas dispo
    let hash = 0;
    for (let i = 0; i < dataString.length; i++) {
      hash = ((hash << 5) - hash) + dataString.charCodeAt(i);
      hash |= 0;
    }
    return "0x" + Math.abs(hash).toString(16).padStart(16, '0');
  },

  // Déclenchement d'un rappel d'urgence sur un lot spécifique
  triggerRecall(lotNumber, reason = "Suspicion de contamination bactériologique (E. coli / Listeria)") {
    const lot = TRACE_DATA.lots.find(l => l.lotNumber === lotNumber);
    if (!lot) return null;

    lot.status = "RAPPEL_IMMEDIAT";
    lot.recallReason = reason;
    lot.recallTimestamp = new Date().toISOString();

    // Analyse d'impact descendante (Forward Trace)
    const affectedLots = [lot];

    // Vérifier si d'autres lots partagent le même animal ou la même bande
    TRACE_DATA.lots.forEach(otherLot => {
      if (otherLot.lotNumber !== lot.lotNumber) {
        if (otherLot.animalId && lot.animalId && (otherLot.animalId.includes(lot.animalId) || lot.animalId.includes(otherLot.animalId))) {
          otherLot.status = "RAPPEL_IMMEDIAT";
          otherLot.recallReason = `Contamination croisée issue de l'animal ${lot.animalId}`;
          otherLot.recallTimestamp = lot.recallTimestamp;
          affectedLots.push(otherLot);
        }
      }
    });

    // Établissement de la liste des destinataires à notifier d'urgence
    const distributorsToAlert = affectedLots.map(l => {
      const dist = TRACE_DATA.stakeholders.find(s => s.id === l.distributorId);
      return {
        lotNumber: l.lotNumber,
        productName: l.productName,
        distributor: dist ? dist.name : "Inconnu",
        address: dist ? dist.address : "N/A",
        packagingDate: l.packagingDate,
        expiryDate: l.expiryDate,
        status: "URGENT - RETIRER DES RAYONS"
      };
    });

    return {
      triggeredAt: lot.recallTimestamp,
      primaryLot: lotNumber,
      reason: reason,
      affectedLotsCount: affectedLots.length,
      affectedLots: affectedLots,
      distributorsToAlert: distributorsToAlert,
      dgccrfReportGenerated: true
    };
  },

  // Réinitialiser le statut d'un lot (Levée du rappel)
  clearRecall(lotNumber) {
    const lot = TRACE_DATA.lots.find(l => l.lotNumber === lotNumber);
    if (lot) {
      lot.status = "CONFORME";
      delete lot.recallReason;
      delete lot.recallTimestamp;
      return true;
    }
    return false;
  },

  // Obtenir la chaîne complète de traçabilité d'un lot (Ascendance)
  getCompleteTraceChain(lotNumber) {
    const lot = TRACE_DATA.lots.find(l => l.lotNumber === lotNumber);
    if (!lot) return null;

    const farm = TRACE_DATA.stakeholders.find(s => s.id === lot.farmId);
    const slaughterhouse = TRACE_DATA.stakeholders.find(s => s.id === lot.slaughterhouseId);
    const cuttingPlant = TRACE_DATA.stakeholders.find(s => s.id === lot.cuttingPlantId);
    const distributor = TRACE_DATA.stakeholders.find(s => s.id === lot.distributorId);

    return {
      lot,
      farm,
      slaughterhouse,
      cuttingPlant,
      distributor,
      blockchainAuditProof: {
        merkleRoot: "0x8fa3b7e41d8e6c40a5bc920f12a938c5d4ef67812bc691230491823abce",
        blockNumber: 1482903,
        recordedAt: lot.packagingDate + "T10:00:00Z",
        tamperEvident: true
      }
    };
  }
};
