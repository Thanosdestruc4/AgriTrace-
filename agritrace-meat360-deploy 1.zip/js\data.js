/**
 * Base de données de démonstration - Solution Numérique de Traçabilité de Viande
 * Supporte le multi-espèces (Bovin, Porcin, Ovin, Volaille)
 * Conforme aux standards GS1 EPCIS et règlements CE 1760/2000 & Paquet Hygiène
 */

const TRACE_DATA = {
  systemInfo: {
    name: "AgriTrace Meat 360",
    version: "2.4.0",
    lastSync: "2026-11-05T15:30:00Z",
    activeSpecies: ["Bovin", "Porcin", "Ovin", "Volaille"],
    certifications: ["Bio", "Label Rouge", "AOP / IGP", "Bleu-Blanc-Cœur", "VBF (Viande Bovine Française)"]
  },

  // Acteurs agréés de la filière
  stakeholders: [
    {
      id: "FAR-001",
      gln: "3700123400018",
      name: "GAEC des Prés Verts",
      type: "Élevage Bovin & Ovin",
      manager: "Jean-Marc & Sylvie Dupont",
      address: "Route du Bocage, 71120 Charolles, France",
      coords: [46.4344, 4.2758],
      certifications: ["Label Rouge", "Charolais du Bourbonnais IGP", "Haute Valeur Environnementale (HVE)"],
      phone: "+33 3 85 24 11 02",
      veterinarian: "Dr. Bernard Roy (Cabinet VetCharolles)",
      surface: "185 hectares de prairies permanentes",
      diet: "Herbe pâturée d'avril à novembre, foin et céréales produites sur la ferme, sans OGM",
      photo: "https://images.unsplash.com/photo-1500595046743-cd271d694d30?auto=format&fit=crop&w=800&q=80"
    },
    {
      id: "FAR-002",
      gln: "3700123400025",
      name: "Ferme Avicole de la Vallée Verte",
      type: "Élevage Volaille",
      manager: "Marie & Loïc Le Gall",
      address: "Lieu-dit Kermaria, 29150 Châteaulin, France",
      coords: [48.1965, -4.0911],
      certifications: ["Label Rouge Volailles de Bretagne", "Agriculture Biologique"],
      phone: "+33 2 98 86 45 12",
      veterinarian: "Dr. Armelle Gourvennec",
      surface: "Parcours arboré plein air de 2 hectares",
      diet: "100% végétal, minéraux et vitamines, dont 75% de céréales, garanti sans OGM",
      photo: "https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?auto=format&fit=crop&w=800&q=80"
    },
    {
      id: "FAR-003",
      gln: "3700123400032",
      name: "Élevage Porcin des Monts d'Auvergne",
      type: "Élevage Porcin",
      manager: "Pierre Fournier",
      address: "Les Bruyères, 63230 Saint-Ours, France",
      coords: [45.8503, 2.8941],
      certifications: ["Porc Fermier d'Auvergne IGP", "Filière Bleu-Blanc-Cœur"],
      phone: "+33 4 73 88 77 00",
      veterinarian: "Dr. Marc Chatelet",
      surface: "Plein air et bâtiments sur paille",
      diet: "Céréales d'Auvergne enrichies en graines de lin naturelles (Omega 3)",
      photo: "https://images.unsplash.com/photo-1516467508483-a7212febe31a?auto=format&fit=crop&w=800&q=80"
    },
    {
      id: "FAR-004",
      gln: "3700123400049",
      name: "Bergerie Pastorale des Hauts Plateaux",
      type: "Élevage Ovin",
      manager: "Julien Ravel",
      address: "Plateau de Ganagobie, 04200 Sisteron, France",
      coords: [44.1989, 5.9428],
      certifications: ["Agneau de Sisteron Label Rouge", "IGP Agneau de Sisteron"],
      phone: "+33 4 92 61 30 19",
      veterinarian: "Dr. Claire Martin",
      surface: "350 hectares de parcours en estive",
      diet: "Allaitement maternel minimum 60 jours, flore des Alpes de Haute-Provence",
      photo: "https://images.unsplash.com/photo-1484557052118-f32bd25b45b5?auto=format&fit=crop&w=800&q=80"
    },
    {
      id: "ABAT-001",
      gln: "3700987600014",
      name: "Abattoir Régional du Charolais & Sud-Bourgogne",
      sanitaryNumber: "FR 71.120.001 CE",
      type: "Abattoir Polyvalent (Bovins, Ovins)",
      address: "Zone Industrielle de Bellevue, 71120 Charolles",
      manager: "Frédéric Vasseur",
      vetAuthority: "DDPP 71 - Direction Départementale de la Protection des Populations"
    },
    {
      id: "ABAT-002",
      gln: "3700987600021",
      name: "Abattoir Avicole d'Armorique",
      sanitaryNumber: "FR 29.045.010 CE",
      type: "Abattoir Spécialisé Volailles",
      address: "Parc d'Activités des Korrigans, 29150 Châteaulin",
      manager: "Gilles Kerviel",
      vetAuthority: "DDPP 29"
    },
    {
      id: "CUT-001",
      gln: "3700543200011",
      name: "Atelier de Découpe & Conditionnement Bourgogne Viandes",
      sanitaryNumber: "FR 71.056.002 CE",
      type: "Atelier de Découpe et Transformation Agréé",
      address: "Espace Agro-Pôle, 71000 Mâcon",
      certifications: ["IFS Food v8", "BRCGS Packaging", "HACCP certifié AFNOR"]
    },
    {
      id: "DIST-001",
      gln: "3700777700019",
      name: "Boucherie Traditionnelle de la Halle",
      type: "Boucherie Artisanale",
      address: "14 Place Bellecour, 69002 Lyon"
    },
    {
      id: "DIST-002",
      gln: "3700777700026",
      name: "Hypermarché Grand Frais & Saveurs",
      type: "Grande Distribution (GMS)",
      address: "Boulevard Urbain Sud, 69007 Lyon"
    }
  ],

  // Lots de produits finis (barquettes / pièces sous vide)
  lots: [
    {
      lotNumber: "LOT-BOV-2026-884",
      gtin: "3760123456789",
      species: "Bovin",
      productName: "Côte de Bœuf Charolaise d'Exception (1 kg env.)",
      cutType: "Côte de bœuf avec os, affinée 21 jours",
      packagingDate: "2026-11-01",
      expiryDate: "2026-11-15",
      temperatureTarget: "0°C à +2°C",
      weightKg: 1.05,
      animalId: "FR 71 2098 4421",
      breed: "Charolaise pure race",
      birthDate: "2023-04-12",
      gender: "Génisse (femelle n'ayant pas vêlé)",
      farmId: "FAR-001",
      slaughterhouseId: "ABAT-001",
      slaughterDate: "2026-10-11",
      slaughterNumber: "TUERIE-8492",
      cuttingPlantId: "CUT-001",
      distributorId: "DIST-001",
      carcassWeight: 428.5,
      carcassEuropClass: "U 3 (Excellente conformation musculaire, état d'engraissement équilibré)",
      phValue: 5.58, // pH optimal
      status: "CONFORME", // ou "RAPPEL_IMMEDIAT"
      coldChainAlert: false,
      currentTemp: 1.8,
      qrCodeId: "QR-BOV-884",
      digitalLink: "https://trace.viande.fr/01/3760123456789/10/LOT-BOV-2026-884",
      certifications: ["Label Rouge", "Charolais du Bourbonnais IGP", "100% Terroir Français"],
      consumerTips: {
        preparation: "Sortir la viande du réfrigérateur 1h avant la cuisson. Saisir à feu très vif 2 min par face puis baisser à feu moyen 4 min par face. Laisser reposer sous papier alu 5 min.",
        pairing: "À déguster avec un vin rouge de Bourgogne (Mercurey ou Moulin-à-Vent)."
      }
    },
    {
      lotNumber: "LOT-BOV-HACHE-902",
      gtin: "3760123456796",
      species: "Bovin",
      productName: "Steaks Hachés Pur Bœuf Façon Bouchère 15% MG (x2)",
      cutType: "Préparation de viande hachée pur muscle",
      packagingDate: "2026-11-04",
      expiryDate: "2026-11-10",
      temperatureTarget: "0°C à +2°C",
      weightKg: 0.25,
      // Exemple de mélange multi-animaux réglementé (max 3-5 carcasses pour le haché)
      multiAnimalSources: [
        { animalId: "FR 71 2098 4421", farmId: "FAR-001", partKg: 45.0 },
        { animalId: "FR 71 2098 4429", farmId: "FAR-001", partKg: 55.0 }
      ],
      animalId: "FR 71 2098 4421 / FR 71 2098 4429",
      breed: "Charolaise",
      birthDate: "2023-04-12 / 2023-04-18",
      gender: "Génisses",
      farmId: "FAR-001",
      slaughterhouseId: "ABAT-001",
      slaughterDate: "2026-10-28",
      slaughterNumber: "TUERIE-8510 & 8511",
      cuttingPlantId: "CUT-001",
      distributorId: "DIST-002",
      carcassWeight: 840.0,
      carcassEuropClass: "R+ 3",
      phValue: 5.62,
      status: "CONFORME",
      coldChainAlert: false,
      currentTemp: 1.4,
      qrCodeId: "QR-BOV-HACHE-902",
      digitalLink: "https://trace.viande.fr/01/3760123456796/10/LOT-BOV-HACHE-902",
      certifications: ["Viande Bovine Française (VBF)", "HACCP Contrôle Renforcé"],
      consumerTips: {
        preparation: "Cuire à cœur pour les enfants, personnes âgées et femmes enceintes (température interne 70°C).",
        pairing: "Pommes grenailles sautées au romarin."
      }
    },
    {
      lotNumber: "LOT-VOL-2026-119",
      gtin: "3760123456819",
      species: "Volaille",
      productName: "Filets de Poulet Fermier de Bretagne Label Rouge (x2)",
      cutType: "Blancs de poulet avec peau fine",
      packagingDate: "2026-11-03",
      expiryDate: "2026-11-14",
      temperatureTarget: "0°C à +4°C",
      weightKg: 0.38,
      batchBandId: "BANDE-BRE-2026-042 (4 500 volailles)",
      animalId: "Lot de bande #042",
      breed: "Poulet fermier à croissance lente (souche cou nu)",
      birthDate: "2026-08-10 (Élevage 85 jours minimum)",
      gender: "Mâles et femelles",
      farmId: "FAR-002",
      slaughterhouseId: "ABAT-002",
      slaughterDate: "2026-11-02",
      slaughterNumber: "TUERIE-VOL-441",
      cuttingPlantId: "CUT-001",
      distributorId: "DIST-002",
      carcassWeight: 2.1,
      carcassEuropClass: "Classe A - Finition supérieure",
      phValue: 5.85,
      status: "CONFORME",
      coldChainAlert: false,
      currentTemp: 2.3,
      qrCodeId: "QR-VOL-119",
      digitalLink: "https://trace.viande.fr/01/3760123456819/10/LOT-VOL-2026-119",
      certifications: ["Label Rouge", "IGP Volailles de Bretagne", "Élevé en plein air 85 jours"],
      consumerTips: {
        preparation: "Dorer à la poêle 4 minutes de chaque côté dans une noisette de beurre clarifié, puis terminer à couvert à feu doux 5 minutes.",
        pairing: "Légumes racines rôtis au thym."
      }
    },
    {
      lotNumber: "LOT-PORC-2026-553",
      gtin: "3760123456826",
      species: "Porcin",
      productName: "Rôti de Porc Fermier d'Auvergne dans le Filet (800g)",
      cutType: "Rôti ficelé sans barde",
      packagingDate: "2026-11-02",
      expiryDate: "2026-11-12",
      temperatureTarget: "0°C à +4°C",
      weightKg: 0.82,
      animalId: "TATOUAGE-FR-63-9912",
      breed: "Porc Large White x Piétrain élevé sur paille",
      birthDate: "2026-05-02 (6 mois d'élevage)",
      gender: "Porc charcutier",
      farmId: "FAR-003",
      slaughterhouseId: "ABAT-001",
      slaughterDate: "2026-10-31",
      slaughterNumber: "TUERIE-P-1204",
      cuttingPlantId: "CUT-001",
      distributorId: "DIST-001",
      carcassWeight: 92.4,
      carcassEuropClass: "TMP 61.4% (Classe S - Viande très maigre)",
      phValue: 5.65,
      status: "CONFORME",
      coldChainAlert: false,
      currentTemp: 2.7,
      qrCodeId: "QR-PORC-553",
      digitalLink: "https://trace.viande.fr/01/3760123456826/10/LOT-PORC-2026-553",
      certifications: ["Porc Fermier d'Auvergne IGP", "Bleu-Blanc-Cœur", "Nourri sans OGM"],
      consumerTips: {
        preparation: "Préchauffer le four à 180°C. Cuire 45 minutes en arrosant régulièrement de son jus aux herbes de Provence.",
        pairing: "Gratin dauphinois traditionnel."
      }
    },
    {
      lotNumber: "LOT-OVIN-2026-302",
      gtin: "3760123456833",
      species: "Ovin",
      productName: "Gigot d'Agneau de Sisteron Raccourci (1.4 kg)",
      cutType: "Gigot avec manche court",
      packagingDate: "2026-11-03",
      expiryDate: "2026-11-16",
      temperatureTarget: "0°C à +2°C",
      weightKg: 1.42,
      animalId: "FR 04 8832 1045",
      breed: "Préalpes du Sud & Mérinos",
      birthDate: "2026-07-15",
      gender: "Agneau de lait et d'herbe",
      farmId: "FAR-004",
      slaughterhouseId: "ABAT-001",
      slaughterDate: "2026-11-02",
      slaughterNumber: "TUERIE-OV-650",
      cuttingPlantId: "CUT-001",
      distributorId: "DIST-001",
      carcassWeight: 18.2,
      carcassEuropClass: "E 2 (Conformation excellente, gras léger)",
      phValue: 5.60,
      status: "CONFORME",
      coldChainAlert: false,
      currentTemp: 1.9,
      qrCodeId: "QR-OVIN-302",
      digitalLink: "https://trace.viande.fr/01/3760123456833/10/LOT-OVIN-2026-302",
      certifications: ["Agneau de Sisteron Label Rouge", "IGP Sisteron", "Élevage Pastoral"],
      consumerTips: {
        preparation: "Piquer de gousses d'ail. Cuisson 15 min à 220°C puis 25 min à 180°C pour une viande rosée et fondante.",
        pairing: "Flageolets cuisinés ou tian de légumes provençaux."
      }
    }
  ],

  // Historique de température IoT pour la simulation de chaîne du froid
  coldChainSensors: [
    {
      sensorId: "IOT-FRIGO-CAM-402",
      name: "Camion Frigo Châteaulin -> Mâcon",
      type: "Transport frigorifique Classe C",
      currentTemp: 2.1,
      minTemp: 0.5,
      maxTemp: 3.8,
      alertThreshold: 4.0,
      status: "NORMAL",
      dataPoints: [
        { time: "08:00", temp: 1.9 },
        { time: "09:00", temp: 2.2 },
        { time: "10:00", temp: 2.4 },
        { time: "11:00", temp: 2.1 },
        { time: "12:00", temp: 3.2 },
        { time: "13:00", temp: 2.0 },
        { time: "14:00", temp: 1.8 },
        { time: "15:00", temp: 2.1 }
      ]
    },
    {
      sensorId: "IOT-CHAMBRE-FROIDE-C1",
      name: "Chambre Froide Maturation Viandes #1",
      type: "Stockage fixe Mâcon",
      currentTemp: 1.2,
      minTemp: 0.0,
      maxTemp: 2.0,
      alertThreshold: 3.0,
      status: "OPTIMAL",
      dataPoints: [
        { time: "08:00", temp: 1.1 },
        { time: "09:00", temp: 1.2 },
        { time: "10:00", temp: 1.3 },
        { time: "11:00", temp: 1.2 },
        { time: "12:00", temp: 1.4 },
        { time: "13:00", temp: 1.2 },
        { time: "14:00", temp: 1.1 },
        { time: "15:00", temp: 1.2 }
      ]
    }
  ],

  // ========================================================
  // MODULE GESTION DES STOCKS & PRÉVENTION DU VOL / COULAGE
  // ========================================================
  stockLocations: [
    { id: "LOC-CF1", name: "Chambre Froide Carcasses #1 (Bovins/Porcins)", capacityKg: 25000, currentWeightKg: 18450.0, temp: 1.4 },
    { id: "LOC-CF2", name: "Chambre Froide Pièces Nobles & Maturation #2", capacityKg: 8000, currentWeightKg: 6120.5, temp: 1.1 },
    { id: "LOC-EXP", name: "Quai d'Expédition Réfrigéré (SAS de Sortie)", capacityKg: 12000, currentWeightKg: 3240.0, temp: 2.8 }
  ],

  // Inventaire physique par référence et contrôle des écarts (Théorique vs Réel)
  inventoryItems: [
    {
      sku: "BOV-CARC-U3",
      species: "Bovin",
      category: "Carcasses entières / Demi-carcasses",
      designation: "Demi-Carcasses Bœuf Charolais U3",
      locationId: "LOC-CF1",
      unit: "Pièces (demi)",
      theoreticalQty: 24,
      physicalQty: 24,
      theoreticalWeightKg: 5140.0,
      physicalWeightKg: 5045.0, // Perte normale au ressuage (-1.85%)
      pricePerKg: 7.80,
      normalShrinkagePct: 2.0, // Perte d'eau naturelle admissible
      measuredLossPct: 1.85,
      theftRiskLevel: "FAIBLE",
      status: "CONFORME",
      rfidTags: ["TAG-BOV-001", "TAG-BOV-002", "TAG-BOV-003"]
    },
    {
      sku: "BOV-NOB-FILET",
      species: "Bovin",
      category: "Pièces Nobles à Très Haute Valeur",
      designation: "Filets de Bœuf sous-vide entiers (pièce noble)",
      locationId: "LOC-CF2",
      unit: "Pièces sous vide",
      theoreticalQty: 32,
      physicalQty: 29, // DISPARITION DE 3 PIÈCES !
      theoreticalWeightKg: 144.0,
      physicalWeightKg: 130.5, // Manque 13.5 kg
      pricePerKg: 42.00, // Pièce très chère = cible privilégiée de vol
      normalShrinkagePct: 0.1, // Sous vide = quasi zéro perte en eau
      measuredLossPct: 9.38,
      theftRiskLevel: "CRITIQUE",
      status: "SUSPICION_VOL",
      missingDetail: "3 pièces manquantes constatées lors du contrôle SAS de 06h30. Valeur dérobée estimée : 567,00 €",
      rfidTags: ["TAG-FIL-101", "TAG-FIL-102"]
    },
    {
      sku: "BOV-NOB-ENTREC",
      species: "Bovin",
      category: "Pièces Nobles à Haute Valeur",
      designation: "Noix d'Entrecôtes Affinées 21 jours",
      locationId: "LOC-CF2",
      unit: "Cartons calibrés 10kg",
      theoreticalQty: 18,
      physicalQty: 18,
      theoreticalWeightKg: 180.0,
      physicalWeightKg: 178.5,
      pricePerKg: 28.50,
      normalShrinkagePct: 1.0,
      measuredLossPct: 0.83,
      theftRiskLevel: "MOYEN",
      status: "CONFORME",
      rfidTags: ["TAG-ENT-201", "TAG-ENT-202"]
    },
    {
      sku: "PORC-JAMB-AUV",
      species: "Porcin",
      category: "Pièces Porcines Nobles",
      designation: "Jambons Frais avec os Porc Auvergne IGP",
      locationId: "LOC-CF1",
      unit: "Jambons entiers",
      theoreticalQty: 60,
      physicalQty: 58, // 2 JAMBONS MANQUANTS
      theoreticalWeightKg: 720.0,
      physicalWeightKg: 696.0,
      pricePerKg: 9.20,
      normalShrinkagePct: 1.5,
      measuredLossPct: 3.33,
      theftRiskLevel: "ÉLEVÉ",
      status: "SUSPICION_VOL",
      missingDetail: "2 jambons non tracés sortis sans bon de préparation. Valeur : 220,80 €",
      rfidTags: ["TAG-JAMB-301"]
    },
    {
      sku: "VOL-POUL-BRES",
      species: "Volaille",
      category: "Volaille Conditionnée",
      designation: "Caisses de Poulets Fermiers Label Rouge (x6)",
      locationId: "LOC-CF1",
      unit: "Caisses de 6",
      theoreticalQty: 85,
      physicalQty: 85,
      theoreticalWeightKg: 1071.0,
      physicalWeightKg: 1068.0,
      pricePerKg: 8.50,
      normalShrinkagePct: 0.5,
      measuredLossPct: 0.28,
      theftRiskLevel: "FAIBLE",
      status: "CONFORME",
      rfidTags: ["TAG-VOL-401"]
    },
    {
      sku: "OVIN-GIGOT-SIS",
      species: "Ovin",
      category: "Pièces Nobles Agneau",
      designation: "Gigots d'Agneau de Sisteron Raccourcis",
      locationId: "LOC-CF2",
      unit: "Pièces sous filet",
      theoreticalQty: 40,
      physicalQty: 40,
      theoreticalWeightKg: 80.0,
      physicalWeightKg: 79.2,
      pricePerKg: 24.00,
      normalShrinkagePct: 1.2,
      measuredLossPct: 1.0,
      theftRiskLevel: "MOYEN",
      status: "CONFORME",
      rfidTags: ["TAG-OV-501"]
    }
  ],

  // Journal des mouvements sécurisés aux sas de contrôle & portiques RFID
  stockMovements: [
    {
      id: "MVT-2026-9901",
      timestamp: "2026-11-06T07:12:00",
      operatorId: "OP-44 (Marc V.)",
      badgeId: "RFID-BADGE-8841",
      sku: "BOV-CARC-U3",
      designation: "Transfert 4 demi-carcasses vers Découpe",
      type: "TRANSFERT_INTERNE",
      qty: 4,
      weightKg: 856.2,
      sourceLocation: "LOC-CF1",
      targetLocation: "Atelier Découpe",
      exitAuthNumber: "OF-2026-1102",
      status: "AUTORISÉ_CONFORME"
    },
    {
      id: "MVT-2026-9902",
      timestamp: "2026-11-06T06:18:22",
      operatorId: "INCONNU / NON BADGÉ",
      badgeId: "NON_DÉTECTÉ",
      sku: "BOV-NOB-FILET",
      designation: "Sortie Portique SAS Quai Nord",
      type: "SORTIE_NON_AUTORISÉE",
      qty: 3,
      weightKg: 13.5,
      sourceLocation: "LOC-CF2",
      targetLocation: "Quai Nord / Inconnu",
      exitAuthNumber: "AUCUN BON D'EXPÉDITION",
      status: "ALERTE_VOL_DÉCLENCHÉE"
    },
    {
      id: "MVT-2026-9903",
      timestamp: "2026-11-06T05:45:10",
      operatorId: "OP-12 (Alain B.)",
      badgeId: "RFID-BADGE-1209",
      sku: "VOL-POUL-BRES",
      designation: "Chargement Camion Frigo #TR-402",
      type: "EXPÉDITION_CLIENT",
      qty: 25,
      weightKg: 315.0,
      sourceLocation: "LOC-EXP",
      targetLocation: "Camion #TR-402",
      exitAuthNumber: "BL-GMS-69002",
      status: "AUTORISÉ_CONFORME"
    }
  ]
};
