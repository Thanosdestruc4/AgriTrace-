/**
 * Simulateur IoT en temps réel pour le monitoring de la chaîne du froid
 * Télémétrie MQTT simulée, seuils d'alertes sanitaires et détection de ruptures thermiques
 */

const IoTSimulator = {
  chartInstance: null,
  activeSensorId: "IOT-FRIGO-CAM-402",
  timer: null,

  init(chartCanvasId) {
    const canvas = document.getElementById(chartCanvasId);
    if (!canvas || !window.Chart) return;

    const sensor = TRACE_DATA.coldChainSensors.find(s => s.id === this.activeSensorId);
    if (!sensor) return;

    const ctx = canvas.getContext('2d');
    this.chartInstance = new Chart(ctx, {
      type: 'line',
      data: {
        labels: sensor.dataPoints.map(p => p.time),
        datasets: [
          {
            label: `Température Mesurée (°C) - ${sensor.name}`,
            data: sensor.dataPoints.map(p => p.temp),
            borderColor: '#059669',
            backgroundColor: 'rgba(5, 150, 105, 0.1)',
            fill: true,
            tension: 0.3,
            pointRadius: 4,
            pointBackgroundColor: '#059669'
          },
          {
            label: 'Seuil Réglementaire Max (+4.0°C)',
            data: sensor.dataPoints.map(() => 4.0),
            borderColor: '#dc2626',
            borderDash: [5, 5],
            fill: false,
            pointRadius: 0
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            min: -1,
            max: 8,
            title: {
              display: true,
              text: 'Température (°C)'
            }
          }
        },
        plugins: {
          legend: {
            position: 'top'
          }
        }
      }
    });

    this.startAutoUpdate();
  },

  selectSensor(sensorId) {
    this.activeSensorId = sensorId;
    const sensor = TRACE_DATA.coldChainSensors.find(s => s.id === sensorId);
    if (!sensor || !this.chartInstance) return;

    this.chartInstance.data.labels = sensor.dataPoints.map(p => p.time);
    this.chartInstance.data.datasets[0].label = `Température Mesurée (°C) - ${sensor.name}`;
    this.chartInstance.data.datasets[0].data = sensor.dataPoints.map(p => p.temp);
    this.chartInstance.data.datasets[1].data = sensor.dataPoints.map(() => sensor.alertThreshold || 4.0);
    this.updateColorState(sensor);
    this.chartInstance.update();
  },

  updateColorState(sensor) {
    if (!this.chartInstance) return;
    const isOverheated = sensor.currentTemp > sensor.alertThreshold;
    this.chartInstance.data.datasets[0].borderColor = isOverheated ? '#dc2626' : '#059669';
    this.chartInstance.data.datasets[0].backgroundColor = isOverheated ? 'rgba(220, 38, 38, 0.15)' : 'rgba(5, 150, 105, 0.1)';
    this.chartInstance.data.datasets[0].pointBackgroundColor = isOverheated ? '#dc2626' : '#059669';
  },

  startAutoUpdate() {
    if (this.timer) clearInterval(this.timer);
    this.timer = setInterval(() => {
      const sensor = TRACE_DATA.coldChainSensors.find(s => s.id === this.activeSensorId);
      if (!sensor || !this.chartInstance) return;

      // Légère fluctuation naturelle (+/- 0.1°C) si pas en état d'incident provoqué
      if (sensor.status !== "INCIDENT_THERMIQUE") {
        const delta = (Math.random() - 0.48) * 0.15;
        let newTemp = Math.round((sensor.currentTemp + delta) * 10) / 10;
        if (newTemp < 0.5) newTemp = 0.8;
        if (newTemp > 3.4) newTemp = 3.2;
        sensor.currentTemp = newTemp;
      }

      const now = new Date();
      const timeStr = now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

      // Garder les 10 derniers points
      if (sensor.dataPoints.length > 10) {
        sensor.dataPoints.shift();
      }
      sensor.dataPoints.push({ time: timeStr, temp: sensor.currentTemp });

      this.chartInstance.data.labels = sensor.dataPoints.map(p => p.time);
      this.chartInstance.data.datasets[0].data = sensor.dataPoints.map(p => p.temp);
      this.chartInstance.data.datasets[1].data = sensor.dataPoints.map(() => sensor.alertThreshold || 4.0);
      this.updateColorState(sensor);
      this.chartInstance.update('none');

      // Mettre à jour l'indicateur UI
      const badge = document.getElementById('iotCurrentTempBadge');
      if (badge) {
        badge.textContent = `${sensor.currentTemp} °C`;
        if (sensor.currentTemp > sensor.alertThreshold) {
          badge.className = "text-xl font-bold font-mono text-red-600 bg-red-100 px-3 py-1 rounded-lg border border-red-300 animate-pulse";
        } else {
          badge.className = "text-xl font-bold font-mono text-emerald-700 bg-emerald-100 px-3 py-1 rounded-lg border border-emerald-300";
        }
      }
    }, 3000);
  },

  // Simuler une panne du groupe frigorifique (+6.8°C)
  simulateBreakdown() {
    const sensor = TRACE_DATA.coldChainSensors.find(s => s.id === this.activeSensorId);
    if (!sensor) return;

    sensor.status = "INCIDENT_THERMIQUE";
    sensor.currentTemp = 6.8; // Dépassement critique du seuil de +4°C

    const now = new Date();
    const timeStr = now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    sensor.dataPoints.push({ time: timeStr, temp: 6.8 });

    this.selectSensor(this.activeSensorId);

    // Mettre à jour les lots transportés par ce camion
    const affected = TRACE_DATA.lots.filter(l => l.species === "Volaille" || l.species === "Bovin");
    affected.forEach(l => {
      l.coldChainAlert = true;
      l.currentTemp = 6.8;
    });

    if (window.App) {
      window.App.renderLotsTable();
      window.App.showNotification("Alerte Chaîne du Froid : Température critique détectée à +6.8°C sur le transport !", "error");
    }
  },

  // Rétablir la température normale
  resetTemperature() {
    const sensor = TRACE_DATA.coldChainSensors.find(s => s.id === this.activeSensorId);
    if (!sensor) return;

    sensor.status = "OPTIMAL";
    sensor.currentTemp = 2.0;

    TRACE_DATA.lots.forEach(l => {
      l.coldChainAlert = false;
      l.currentTemp = 2.0;
    });

    this.selectSensor(this.activeSensorId);
    if (window.App) {
      window.App.renderLotsTable();
      window.App.showNotification("Chaîne du froid rétablie. Température nominale à +2.0°C.", "success");
    }
  }
};
