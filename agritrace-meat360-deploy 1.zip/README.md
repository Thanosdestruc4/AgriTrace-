# AgriTrace Meat 360 - Solution Numérique de Traçabilité de la Viande

**AgriTrace Meat 360** est une solution logicielle moderne de traçabilité intégrale pour la filière viande (« De la ferme à l'assiette » / *Farm-to-Fork*), multi-espèces (bovine, porcine, ovine et volaille). Elle combine les standards internationaux **GS1 EPCIS**, la télémétrie **IoT** pour la chaîne du froid, et la réassurance consommateur par **QR Code dynamique**.

---

## 🚀 Démarrage Rapide

### Option A : Lancement immédiat en 1 clic (Recommandé)
Faites un clic droit sur `start_server.ps1` puis choisissez **« Exécuter avec PowerShell »**, ou dans un terminal :
```powershell
.\start_server.ps1
```
L'application démarre un serveur local sur le port 8080 et ouvre automatiquement votre navigateur sur `http://localhost:8080`.

### Option B : Ouverture directe
Double-cliquez directement sur le fichier `index.html` pour l'ouvrir dans Google Chrome ou Microsoft Edge (aucune dépendance requise).

---

## 🥩 Filières Multi-Espèces Prises en Charge

1. **Filière Bovine (Charolais AOP / VBF)** :
   - Traçabilité individuelle via boucle auriculaire EDE (ex: `FR 71 2098 4421`).
   - Numéro de tuerie d'abattoir et classification officielle **EUROP** (conformation musculaire et gras).
   - Suivi du pH et maturation en chambre froide.
   - Gestion des mélanges autorisés pour les viandes hachées (ascendance multi-carcasses).

2. **Filière Porcine (Porc Fermier d'Auvergne IGP)** :
   - Traçabilité par élevage, tatouage de carcasse et numéro de lot.
   - Grille de classement TMP (Teneur en Viande Maigre).
   - Filière Bleu-Blanc-Cœur (nourri aux graines de lin naturelles, riche en Oméga-3).

3. **Filière Volaille (Poulet Fermier de Bretagne Label Rouge)** :
   - Traçabilité par **bande de poulailler** (ex: bande de 4 500 volailles).
   - Durée d'élevage certifiée de 84 jours en plein air arboré.

4. **Filière Ovine (Agneau de Sisteron IGP / Label Rouge)** :
   - Élevage pastoral et allaitement maternel minimum 60 jours.

---

## 🌟 Modules Fonctionnels du Prototype

### 1. Vue d'Ensemble & Dashboard
- Indicateurs clés (KPIs) en temps réel : nombre de lots, élevages partenaires agréés, alertes thermiques actives, alertes de rappel DDPP.
- Synthèse visuelle du cycle de vie en 5 étapes.

### 2. Module de Gestion des Stocks & Prévention Anti-Vol (Nouveau)
- **Réconciliation d'Effectifs Réels (Théorique vs Physique)** : Calcul en continu des écarts entre les bons de réception/abattage et l'inventaire physique réel pesé aux crochets.
- **Détection Automatique du Vol et Coulage** :
  - Distinction scientifique entre la perte d'eau normale en chambre froide (**ressuage biologique < 2%**) et la soustraction frauduleuse de viande noble (filets, entrecôtes, jambons).
  - Évaluation financière en temps réel du **préjudice de vol (€)**.
- **Sécurisation des SAS & Portiques RFID** :
  - Journal horodaté des mouvements d'opérateurs avec badge RFID.
  - Détection et blocage immédiat de toute sortie non couverte par un Bon d'Expédition (BL) ou Ordre de Fabrication (OF) validé.
- **Scan Inventaire Express** : Réconciliation instantanée des chambres froides en un clic.

### 3. Registre des Lots & Généalogie (GS1 EPCIS)
- Filtrage instantané par espèce.
- Consultation de l'historique complet pour chaque pièce de viande (arbre généalogique ascendant).
- Formulaire d'enregistrement d'un nouveau lot avec horodatage certifié.

### 3. Registre des Éleveurs & Exploitations Partenaires
- Fiches détaillées des élevages : photos de l'exploitation, vétérinaire sanitaire référent, surface de pâturage, alimentation garantie sans OGM et certifications.

### 4. Télémétrie IoT - Monitoring de la Chaîne du Froid
- Graphique dynamique en temps réel (via *Chart.js*) connecté aux capteurs de transport frigorifique et chambres froides.
- **Bouton de simulation de panne frigorifique** (+6.8°C) : démontre la détection immédiate de rupture de chaîne du froid et le marquage des lots à risque.

### 5. Module d'Urgence Sanitaire (Mock Recall / Rappel DDPP)
- En cas de suspicion de contamination microbiologique (*E. coli*, salmonelle, listeria) :
  - Déclenchement du rappel en **1 clic**.
  - Détection automatique par graphe de dépendance de l'ensemble des lots et barquettes contaminées.
  - Génération de la liste des destinataires et distributeurs à notifier d'urgence.
  - Bascule automatique du QR code consommateur sur un **écran rouge d'alerte sanitaire** bloquant la consommation.

### 6. Portail Consommateur (Simulateur Smartphone)
- Simulation d'un écran de smartphone avec scan d'étiquette.
- Présentation transparente au consommateur :
  - Photo et histoire de l'éleveur.
  - Fiche d'identité de l'animal.
  - Chaîne de transformation vérifiée.
  - Conseils du maître boucher et recettes adaptées au morceau de viande.

### 7. Éditeur et Impression d'Étiquette Réglementaire CE 1760/2000
- Format conforme aux normes industrielles d'abattoir et d'atelier de découpe.
- Mentions légales obligatoires : *Né en, Élevé en, Abattu en, Découpé en, Numéro d'identification animal, N° de lot*.
- QR Code scannable et code GS1-128.
- Prêt pour impression directe (touche Ctrl+P ou bouton Imprimer).

---

## 🔒 Standards Réglementaires et Techniques

- **Règlement Européen (CE) n° 1760/2000** : Étiquetage des viandes bovines et traçabilité individuelle.
- **Règlement (CE) n° 178/2002 (Paquet Hygiène)** : Obligation de traçabilité « un pas en avant, un pas en arrière ».
- **Norme GS1 EPCIS 2.0** : Format universel d'échange d'événements de chaîne logistique.
- **Cryptographic Audit Trail** : Empreinte de hachage SHA-256 / Merkle Tree pour certifier l'intégrité des événements contre toute altération ou falsification.
