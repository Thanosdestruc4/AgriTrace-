<#
.SYNOPSIS
    Lance l'application web de Traçabilité de Viande en local.
.DESCRIPTION
    Démarre un serveur HTTP local léger en PowerShell (sans dépendance externe)
    et ouvre l'application dans votre navigateur par défaut.
#>

$port = 8080
$url = "http://localhost:$port/"
$folder = $PSScriptRoot

Write-Host "==========================================================" -ForegroundColor Green
Write-Host "  AgriTrace Meat 360 - Solution Numérique de Traçabilité" -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Green
Write-Host "Dossier racine : $folder"
Write-Host "URL locale     : $url"
Write-Host "Appuyez sur Ctrl+C dans cette console pour arrêter le serveur." -ForegroundColor Yellow
Write-Host "----------------------------------------------------------"

# Ouvrir directement le navigateur
Start-Process $url

# Démarrer le serveur HTTP natif .NET
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")
$listener.Start()

try {
    while ($listener.IsListening) {
        try {
            $context = $listener.GetContext()
            $request = $context.Request
            $response = $context.Response

            $localPath = $request.Url.LocalPath.TrimStart('/')
            if ([string]::IsNullOrEmpty($localPath)) {
                $localPath = "index.html"
            }

            $filePath = Join-Path $folder $localPath

            if (Test-Path $filePath -PathType Leaf) {
                $bytes = [System.IO.File]::ReadAllBytes($filePath)
                
                # Détection du type MIME
                $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
                $mime = switch ($ext) {
                    ".html" { "text/html; charset=utf-8" }
                    ".css"  { "text/css; charset=utf-8" }
                    ".js"   { "application/javascript; charset=utf-8" }
                    ".json" { "application/json; charset=utf-8" }
                    ".png"  { "image/png" }
                    ".jpg"  { "image/jpeg" }
                    ".svg"  { "image/svg+xml" }
                    default { "application/octet-stream" }
                }

                $response.ContentType = $mime
                $response.ContentLength64 = $bytes.Length

                if ($request.HttpMethod -ne "HEAD") {
                    $response.OutputStream.Write($bytes, 0, $bytes.Length)
                }
            } else {
                $response.StatusCode = 404
                $errorBytes = [System.Text.Encoding]::UTF8.GetBytes("404 Non trouve")
                $response.ContentLength64 = $errorBytes.Length
                if ($request.HttpMethod -ne "HEAD") {
                    $response.OutputStream.Write($errorBytes, 0, $errorBytes.Length)
                }
            }
            $response.Close()
        } catch {
            Write-Verbose "Erreur requete: $_"
        }
    }
} finally {
    $listener.Stop()
    $listener.Close()
}
